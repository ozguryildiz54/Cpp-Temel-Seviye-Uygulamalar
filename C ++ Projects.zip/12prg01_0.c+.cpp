/*
	12prg01.c++: Bir katar� di�er bir katara kopyalama ...
*/
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <conio.h>

using namespace std;

int main()
{
	int a=21, b=34, toplam;
	toplam=a+b;
	cout << toplam; 
	return 0;
}
