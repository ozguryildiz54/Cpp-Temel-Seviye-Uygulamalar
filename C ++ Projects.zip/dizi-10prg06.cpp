/* 
    10prg06.c++: Bir karakter dizisinin uzunlu�unu bulma.
 */
#include <iostream>
#include <iomanip>
using  namespace std;

int main(void)
{
   char s [40];
   int  k = 0;
 /*
    diziyi okutma i�lemi 
*/
    cout << "Bir seyler yaziniz :";
	gets (s);
/* 
    sonland�r�c� karaktere kadar karakterleri say 
*/
    while (s[k]!='\0' )
    	k++;
    cout <<  "Dizinin uzunlugu  :"   << k << endl;
 return 0;
}

