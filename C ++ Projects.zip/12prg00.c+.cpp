/*
	12prg00.c++: 
*/
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <conio.h>

using namespace std;

int main()
{
	char *mes = "\" ilk.c\" dosyasinin yeri:";
	char *yol = "C:\\WINDOWS\\DESKTOP\\C";
//...
	puts (mes);
	puts (yol);

 return 0;
}


