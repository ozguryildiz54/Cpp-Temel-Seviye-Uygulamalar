#include<stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <locale.h>
int main(int argc, char *argv[]) {
system("color 4e");
setlocale(LC_ALL,"turkish");
char x,y;
printf("karakter giriniz...");
scanf("%c",&x);
//isalnum fonk numarik veya alfabetik de�erleri bulur
if(isalnum(x))
if(isalpha(x)==0)
/*isalpha fonk alfabetik de�ilse 0 d�nd�r�r
tam tersiylede yapabilirdim yani 1 de�eri d�nd�r�rse alfabetiktir 
diyebilirdim ama artistlik olsun diye b�yle yapt�m
*/
printf("\nnumarik bir karakter girdiniz...\n");
else
printf("\nalfabetik bir karakter girdiniz...\n");
else if(isspace(x))//isspace ad�nda belli zaten a��klama yap�yorum
printf("bo�luk karakteri girdiniz");
else
printf("\nalfabetik , numarik veya bo�luk karakteri girmediniz...\n");
/*
isdigit fonk var birde numarik de�erleri buluyor ama yukar�da gerek
kalmadan hallettim laz�m olursa size kullan�m ayn�...
*/
system("pause");
/*not:Baz� arkada�lar�m�z '�' gibi ingilizce harfler girip program yanl�� �al���yor diyor l�tfen sa�malamay�n
*/
return 0;
}
