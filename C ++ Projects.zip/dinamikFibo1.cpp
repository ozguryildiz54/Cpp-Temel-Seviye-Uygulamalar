/*Program� k�saca a��klamak gerekirse; girilen bir say�n�n fibonacci de�erini, iki fonksiyona g�nderiyorum. 
Bu fonksiyonlardan ilki problemi dinamik programlama y�ntemi ile ��zerken, di�eri recursive kavram� ile ��z�yor. 
Aradaki performans fark� �u noktada olu�uyor:

Dinamik Fibonacci fonksiyonunda hesaplanan her de�er bir diziye at�l�yor. 
Yani yeni bir de�er hesaplan�rken s�f�rdan bir hesaplama durumu s�z konusu de�il. 
�nceki de�erler zaten dizide tutuluyordu.

REcursive Fibonacci fonksiyonunda ise her yeni de�er i�in t�m hesaplamalar s�f�rdan yap�l�yor. 
Yani zaten daha �nce hesaplanan de�erler defalarca yeniden hesaplan�yor. 
Bu da haliyle b�y�k bir performans kayb�na neden oluyor.*/
#include <iostream>
using namespace std;

int dinamikFibo(int say);
int recursiveFibo(int sayi);

int main(){
    int sayi;

    cout<<"Bir sayi Giriniz:";
    cin>>sayi;
    cout<<"Dinamik Sonucu:";
    cout<<dinamikFibo(sayi)<<endl;
    cout<<"Recursive Sonucu:";
    cout<<recursiveFibo(sayi);
    cout<<endl;   
    system("pause");
}
  
int dinamikFibo(int n)
{
int sayilar[n+1];
        for(int i=0;i<=n;i++)
        {
              if(i==0)
                 sayilar[i]=0;
              if(i==1)
                 sayilar[i]=1;
              if(i>=2)
                 sayilar[i]=sayilar[i-1]+sayilar[i-2];  
        }
return sayilar[n];
}
//------------------------
//------------------------
int recursiveFibo(int n)
{
if(n==0) 
  return 0;
if(n==1)
  return 1;
return (recursiveFibo(n-1)+recursiveFibo(n-2));
}
