/*
	Random_prg02.c++: RAND_MAX �n de�erini bulma.
*/
#include <iostream>
#include <cstdlib>		/* rand */

using namespace std;
int main ()
{
	cout << "RAND_MAX in degeri : " <<  RAND_MAX << endl; 
  	return 0;
}
