/*
	A basic class contruction ......
*/
#include <iostream>
#include <iomanip>
#include <cmath>
#include <conio.h>
#include <cstring>

using namespace std;

class MyClass{
	private:
		int a;
	public:
		int fonk1 (int no); 
		
}object1, object2, object3,  .... ;

using namespace std;

int main ()
{
	
	return 0;
}

/*
	Class MyClass{
		private :
			fonksiyonlar ve de�i�kenler	

		public :	
			fonksiyonlar ve de�i�kenler
			
		}nesneler;
*/
