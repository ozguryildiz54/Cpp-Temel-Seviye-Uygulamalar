 #include<iostream>
 #include<conio.h>
 #include<stdlib.h>
 #include<Math.h>
 
 using namespace std;
 
 int main(){
 	
 	
 	double x,n,c;

 	
 	
 	cout<<"x sayisi = ";
 	cin>>x;
 	
 	cout<<"n sayisi = ";
 	cin>>n;
 	
 	c=x/n;
 	
	 cout<<"sonuc = "<<c<<endl;	
 			
 	
 	
 	
 	
 	getch();
 	return 0;
 }
 
