#include<iostream>
#define MAX 10
#include <queue>
#include <stack>
using namespace std;

int main()
{
	int value;
int stack[MAX];
int top=-1;
push(stack,top,10);
pop(stack,top,value);

cout<<value;

 return 0;
}

