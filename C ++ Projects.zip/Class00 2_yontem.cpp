/*
	A basic class contruction ......
*/
#include <iostream>
#include <iomanip>
#include <cmath>
#include <conio.h>
#include <cstring>

using namespace std;

class MyClass{
	private:
		int a;
	public:
		int fonk1 (int no); 		
};

using namespace std;

int main ()
{
	MyClass object1;
	MyClass object2;
	MyClass object3;
	.
	.
	.
	return 0;
}

/*
	Class MyClass{
		private :
			fonksiyonlar ve de�i�kenler	

		public :	
			fonksiyonlar ve de�i�kenler
			
		}nesneler;
*/
