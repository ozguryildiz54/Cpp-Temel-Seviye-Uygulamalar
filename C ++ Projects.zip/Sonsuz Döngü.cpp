#include<iostream>
using namespace std;

int main()
{
	int sayi;
	for(sayi=1;sayi=10;sayi++)
	cout<<sayi;
	return 0;
}
