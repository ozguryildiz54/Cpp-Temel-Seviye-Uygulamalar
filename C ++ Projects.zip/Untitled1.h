class deneme
{
	private:
		int x;
	public:
		void f1(int no)
		{
			x=no;
		}
		int f2();
}nesne1, nesne2;

