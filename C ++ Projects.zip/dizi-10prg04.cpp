/*
	10prg04.c++ : Se�erek S�ralama (Selection Sort) Algoritmas� ile bir
	dizinin elemanlar�n� b�y�kten k����e dogru s�ralama.
*/
#include <iostream>
#include <iomanip>
#define n 10
using namespace std; 

int main (void)
{
	int a [n] = {100, -250, 400, 125 ,550, 900, 689, 450, 347, 700};
    int i, j, k, eb;
/*
    Dizinin kendisi
*/
    cout << "once : " ;
    for (k=0; k<n; k++)
    	cout << setw (5) << a[k] ;
/*
	S�rala
*/
	for(k=0; k<n; k++)
	{
		eb = a[k]; 
        i = k;
		for(j=k+1; j<n; j++)
        	if( a[j]>eb )
			{
            	eb = a[j];
             	i = j; 
          	}
       a[i] = a[k];
       a[k] = eb;
	}
/*
	S�ralama bitti
*/
	cout << "\n" << "sonra: ";
   	for(k=0; k<n; k++)
    cout << setw(5) << a[k];
    cout << "\n";

 return 0;
}

