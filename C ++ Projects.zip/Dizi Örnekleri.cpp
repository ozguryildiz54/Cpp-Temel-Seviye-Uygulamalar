#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	char *a, *b;
	//gets(a);
	//gets(b);
	strcpy(a,"sd");
	for(int i=0;i<=a[i];i++)
	cout<<a[i];
	getch();
	return 0;
}
