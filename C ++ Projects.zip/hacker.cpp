#include<iostream>
#include<Math.h>
using namespace std;
void rastgele(int a);
int main()
{
int c;
while(true)
{
	rastgele(c);
}



 return 0;
}
void rastgele(int a)
{
	int b;
	b=Math.random()*20;
	cout<<b;
}
