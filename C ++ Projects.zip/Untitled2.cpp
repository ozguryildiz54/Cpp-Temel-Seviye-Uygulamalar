#include<stdio.h>
int main()
{
 char a[]="naber";
 char b[10];
scanf("%s",&b);
printf("a:%s\nb:%s",a,b);
    return 0;
}
