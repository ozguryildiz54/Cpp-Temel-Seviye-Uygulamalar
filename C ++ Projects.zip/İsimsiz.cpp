// takim ismini ve puanlari yazdiran program...
#include<iostream>
using  namespace std;

int main()
{
	int p1,p2,p3;
	char tak1[20],tak2[20],tak3[20];
	cout<<"birinci takim adini ve puanini giriniz=";cin>>tak1>>p1;
	cout<<"ikinci takim adini ve puanini giriniz=";cin>>tak2>>p2;
	cout<<"ucuncu takim adini ve ouanini giriniz=";cin>>tak3>>p3;
	cout<<"TAKIM\tpuan\n";
	cout<<"...\t...\n";
	cout<<tak1<<"\t"<<p1<<endl;
	cout<<tak2<<"\t"<<p2<<endl;
	cout<<tak3<<"\t"<<p3<<endl;
	return 0;
	
}
