#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x=atoi(argv[1]);
    int y=atoi(argv[2]);
    cout<<x+y<<endl;
  
    return 0;
}
